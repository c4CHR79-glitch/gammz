// Jeu de tir FPS 2D/3D simplifié
const canvas = document.createElement("canvas");
const ctx = canvas.getContext("2d");
canvas.style.cssText = "display:block;width:100vw;height:100vh;background:#000";
document.body.style.cssText = "margin:0;overflow:hidden;cursor:crosshair;background:#05070a;font-family:monospace";
document.body.appendChild(canvas);

const menu = document.createElement("div");
menu.innerHTML = `
  <div class="menu-card">
    <h1>OPÉRATION NOCTURNE</h1>
    <p>ZQSD / WASD — Se déplacer &nbsp;|&nbsp; Souris — Visée &nbsp;|&nbsp; Clic — Tirer &nbsp;|&nbsp; R — Recharger</p>
    <p>Échap — Libérer la souris &nbsp;|&nbsp; F — Plein écran &nbsp;|&nbsp; Maj — Courir</p>
    <button id="play-fullscreen">JOUER EN PLEIN ÉCRAN</button>
  </div>`;
menu.style.cssText = "position:fixed;inset:0;display:flex;align-items:center;justify-content:center;background:rgba(3,6,9,.82);z-index:20;color:#fff;text-align:center;letter-spacing:.5px";
const menuCard = menu.querySelector(".menu-card");
menuCard.style.cssText = "width:min(620px,calc(100% - 32px));padding:28px;border:1px solid #586675;border-radius:12px;background:linear-gradient(145deg,rgba(28,38,48,.96),rgba(10,14,18,.96));box-shadow:0 18px 60px #000";
menu.querySelector("h1").style.cssText = "margin:0 0 18px;color:#78d9ff;font-size:clamp(26px,5vw,46px)";
menu.querySelector("p").style.cssText = "line-height:1.8;color:#d8e2e8";
const playButton = menu.querySelector("#play-fullscreen");
playButton.style.cssText = "margin-top:14px;padding:14px 22px;border:0;border-radius:7px;background:#65d66b;color:#071109;font:700 18px monospace;cursor:pointer";
document.body.appendChild(menu);

let started = false;
let paused = false;
let W = 0, H = 0;
function resize() {
  W = canvas.width = innerWidth;
  H = canvas.height = innerHeight;
}
addEventListener("resize", resize);
resize();

const map = [
  "111111111111",
  "100000000001",
  "101111011101",
  "100001000101",
  "101101110101",
  "100100000001",
  "101101111101",
  "100000010001",
  "111111111111"
];

const player = { x: 1.5, y: 1.5, angle: 0, hp: 100, ammo: 30, reserve: 90, score: 0 };
let enemies = [];
let bullets = [];
let gameOver = false;
let won = false;
let muzzle = 0;
let recoil = 0;
let lastShot = 0;

function blocked(x, y) {
  return !map[Math.floor(y)] || map[Math.floor(y)][Math.floor(x)] === "1";
}

function spawnEnemies() {
  enemies = [
    { x: 9.5, y: 1.5, hp: 3, alive: true, hit: 0, cooldown: 0 },
    { x: 7.5, y: 3.5, hp: 3, alive: true, hit: 0, cooldown: 0 },
    { x: 3.5, y: 5.5, hp: 3, alive: true, hit: 0, cooldown: 0 },
    { x: 9.5, y: 7.5, hp: 3, alive: true, hit: 0, cooldown: 0 }
  ];
}
spawnEnemies();

const keys = {};
addEventListener("keydown", e => {
  const key = e.key.toLowerCase();
  keys[key] = true;
  if (key === "r") reload();
  if (key === "f") toggleFullscreen();
  if (e.key === "Enter" && (gameOver || won)) reset();
});
addEventListener("keyup", e => keys[e.key.toLowerCase()] = false);

canvas.addEventListener("mousemove", e => {
  if (document.pointerLockElement === canvas) player.angle += e.movementX * 0.0025;
});
canvas.addEventListener("click", () => {
  if (!started) return;
  if (document.pointerLockElement !== canvas) canvas.requestPointerLock();
  else shoot();
});

document.addEventListener("pointerlockchange", () => {
  paused = started && document.pointerLockElement !== canvas;
  menu.style.display = paused ? "flex" : "none";
  if (paused) {
    playButton.textContent = "REPRENDRE LE JEU";
  }
});

async function toggleFullscreen() {
  try {
    if (!document.fullscreenElement) await document.documentElement.requestFullscreen();
    else await document.exitFullscreen();
  } catch (_) {}
}

playButton.addEventListener("click", async () => {
  await toggleFullscreen();
  started = true;
  paused = false;
  menu.style.display = "none";
  try { await canvas.requestPointerLock(); } catch (_) {}
});

function reload() {
  if (player.ammo === 30 || player.reserve <= 0) return;
  const needed = 30 - player.ammo;
  const taken = Math.min(needed, player.reserve);
  player.reserve -= taken;
  player.ammo += taken;
}

function shoot() {
  if (gameOver || won) return;
  const now = performance.now();
  if (now - lastShot < 180 || player.ammo <= 0) return;
  player.ammo--;
  lastShot = now;
  muzzle = 8;
  recoil = 12;

  let target = null;
  let targetDist = Infinity;
  for (const enemy of enemies) {
    if (!enemy.alive) continue;
    const dx = enemy.x - player.x;
    const dy = enemy.y - player.y;
    const dist = Math.hypot(dx, dy);
    let diff = Math.atan2(dy, dx) - player.angle;
    diff = Math.atan2(Math.sin(diff), Math.cos(diff));
    if (Math.abs(diff) < 0.055 && dist < targetDist) {
      target = enemy;
      targetDist = dist;
    }
  }
  if (target) {
    target.hp--;
    target.hit = 10;
    if (target.hp <= 0) {
      target.alive = false;
      player.score += 100;
      if (enemies.every(e => !e.alive)) won = true;
    }
  }
}

function reset() {
  player.x = 1.5;
  player.y = 1.5;
  player.angle = 0;
  player.hp = 100;
  player.ammo = 30;
  player.reserve = 90;
  player.score = 0;
  gameOver = false;
  won = false;
  spawnEnemies();
}

function castRay(angle) {
  const maxDist = 20;
  let dist = 0;
  const dx = Math.cos(angle), dy = Math.sin(angle);
  while (dist < maxDist) {
    dist += 0.025;
    if (blocked(player.x + dx * dist, player.y + dy * dist)) break;
  }
  return dist;
}

function update() {
  if (!started || paused || gameOver || won) return;

  let move = 0, strafe = 0;
  if (keys["z"] || keys["arrowup"] || keys["w"]) move += 1;
  if (keys["s"] || keys["arrowdown"]) move -= 1;
  if (keys["q"] || keys["a"]) strafe -= 1;
  if (keys["d"]) strafe += 1;
  if (keys["arrowleft"]) player.angle -= 0.035;
  if (keys["arrowright"]) player.angle += 0.035;

  const speed = keys["shift"] ? 0.085 : 0.055;
  const mx = (Math.cos(player.angle) * move + Math.cos(player.angle + Math.PI / 2) * strafe) * speed;
  const my = (Math.sin(player.angle) * move + Math.sin(player.angle + Math.PI / 2) * strafe) * speed;
  if (!blocked(player.x + mx, player.y)) player.x += mx;
  if (!blocked(player.x, player.y + my)) player.y += my;

  for (const enemy of enemies) {
    if (!enemy.alive) continue;
    if (enemy.hit > 0) enemy.hit--;
    enemy.cooldown--;
    const dx = player.x - enemy.x;
    const dy = player.y - enemy.y;
    const dist = Math.hypot(dx, dy);

    if (dist > 0.65 && dist < 7) {
      const nx = dx / dist, ny = dy / dist;
      const ex = enemy.x + nx * 0.018;
      const ey = enemy.y + ny * 0.018;
      if (!blocked(ex, enemy.y)) enemy.x = ex;
      if (!blocked(enemy.x, ey)) enemy.y = ey;
    }
    if (dist < 0.75 && enemy.cooldown <= 0) {
      player.hp -= 8;
      enemy.cooldown = 70;
      if (player.hp <= 0) {
        player.hp = 0;
        gameOver = true;
      }
    }
  }

  if (keys[" "]) shoot();
  if (muzzle > 0) muzzle--;
  if (recoil > 0) recoil--;
}

function draw() {
  const horizon = H * 0.48;

  ctx.fillStyle = "#10151a";
  ctx.fillRect(0, 0, W, horizon);
  ctx.fillStyle = "#17130f";
  ctx.fillRect(0, horizon, W, H - horizon);

  const fov = Math.PI / 3;
  const columns = Math.ceil(W / 2);
  for (let i = 0; i < columns; i++) {
    const rayAngle = player.angle - fov / 2 + (i / columns) * fov;
    let dist = castRay(rayAngle);
    dist *= Math.cos(rayAngle - player.angle);
    const wallH = Math.min(H * 2, (H * 0.72) / dist);
    const shade = Math.max(35, 165 - dist * 15);
    ctx.fillStyle = `rgb(${shade}, ${shade * 0.72}, ${shade * 0.58})`;
    ctx.fillRect(i * (W / columns), horizon - wallH / 2, Math.ceil(W / columns) + 1, wallH);
  }

  const sprites = enemies
    .filter(e => e.alive)
    .map(e => {
      const dx = e.x - player.x, dy = e.y - player.y;
      let angle = Math.atan2(dy, dx) - player.angle;
      angle = Math.atan2(Math.sin(angle), Math.cos(angle));
      return { enemy: e, dist: Math.hypot(dx, dy), angle };
    })
    .filter(s => Math.abs(s.angle) < fov / 1.5)
    .sort((a, b) => b.dist - a.dist);

  for (const s of sprites) {
    const dist = s.dist;
    const screenX = W / 2 + Math.tan(s.angle) / Math.tan(fov / 2) * W / 2;
    const size = Math.min(H * 1.2, H * 0.5 / dist);
    const y = horizon - size * 0.1;
    ctx.fillStyle = s.enemy.hit > 0 ? "#ffb0a0" : "#542020";
    ctx.fillRect(screenX - size * 0.18, y - size * 0.58, size * 0.36, size * 0.58);
    ctx.fillStyle = "#2b1010";
    ctx.fillRect(screenX - size * 0.23, y - size * 0.78, size * 0.46, size * 0.22);
    ctx.fillStyle = "#d7b27a";
    ctx.fillRect(screenX - size * 0.14, y - size * 0.72, size * 0.08, size * 0.06);
    ctx.fillRect(screenX + size * 0.06, y - size * 0.72, size * 0.08, size * 0.06);
  }

  // Arme au premier plan
  ctx.save();
  ctx.translate(W / 2, H);
  ctx.fillStyle = "#171a1d";
  ctx.fillRect(-W * 0.09 - recoil, -H * 0.20, W * 0.18, H * 0.22);
  ctx.fillStyle = "#34383b";
  ctx.beginPath();
  ctx.moveTo(-W * 0.045, -H * 0.20);
  ctx.lineTo(-W * 0.025, -H * 0.42);
  ctx.lineTo(W * 0.025, -H * 0.42);
  ctx.lineTo(W * 0.045, -H * 0.20);
  ctx.closePath();
  ctx.fill();
  if (muzzle > 0) {
    ctx.fillStyle = "#ffe36e";
    ctx.beginPath();
    ctx.moveTo(0, -H * 0.44);
    ctx.lineTo(-15, -H * 0.30);
    ctx.lineTo(15, -H * 0.30);
    ctx.closePath();
    ctx.fill();
  }
  ctx.restore();

  ctx.fillStyle = "rgba(0,0,0,.55)";
  ctx.fillRect(16, 16, 210, 92);
  ctx.fillStyle = "#fff";
  ctx.font = "bold 21px monospace";
  ctx.fillText(`VIE  ${player.hp}`, 32, 48);
  ctx.fillStyle = player.hp < 30 ? "#ff5544" : "#64d66b";
  ctx.fillRect(32, 58, 150 * player.hp / 100, 10);
  ctx.fillStyle = "#fff";
  ctx.fillText(`BALLES ${player.ammo}/${player.reserve}`, 32, 94);
  if (player.ammo === 0) {
    ctx.fillStyle = "#ff6655";
    ctx.fillText("CHARGEUR VIDE — R", 32, 118);
  }

  ctx.textAlign = "right";
  ctx.fillText(`F = PLEIN ÉCRAN`, W - 24, H - 24);
  ctx.fillText(`SCORE ${player.score}`, W - 24, 48);
  ctx.textAlign = "left";

  ctx.fillStyle = "rgba(255,255,255,.8)";
  ctx.fillRect(W / 2 - 1, H / 2 - 8, 2, 16);
  ctx.fillRect(W / 2 - 8, H / 2 - 1, 16, 2);

  if (gameOver || won) {
    ctx.fillStyle = "rgba(0,0,0,.75)";
    ctx.fillRect(0, 0, W, H);
    ctx.fillStyle = won ? "#65e46d" : "#ff5959";
    ctx.textAlign = "center";
    ctx.font = "bold 54px monospace";
    ctx.fillText(won ? "VICTOIRE !" : "GAME OVER", W / 2, H / 2);
    ctx.fillStyle = "#fff";
    ctx.font = "24px monospace";
    ctx.fillText("Entrée pour rejouer", W / 2, H / 2 + 50);
  }
}

function loop() {
  update();
  draw();
  requestAnimationFrame(loop);
}
loop();