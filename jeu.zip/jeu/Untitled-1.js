// Jeu de voitures en temps réel - Vue pseudo-3D - Canvas HTML
const stylesheet = document.createElement("link");
stylesheet.rel = "stylesheet";
stylesheet.href = "Untitled-1.css";
document.head.appendChild(stylesheet);

const canvas = document.createElement("canvas");
canvas.width = 900;
canvas.height = 560;
canvas.style.cssText = "display:block;width:min(900px,calc(100vw - 32px));height:auto;aspect-ratio:45 / 28;margin:20px auto;border:1px solid #64748b;border-radius:16px;background:#1f2937;box-shadow:0 24px 60px #000a,0 8px 20px #0006,inset 0 0 30px #0006;touch-action:none;";
document.body.style.cssText = "box-sizing:border-box;min-height:100vh;margin:0;padding:20px 0 32px;background:radial-gradient(ellipse at 50% 0%,#334155 0%,#1e293b 42%,#0b1120 100%);color:white;font-family:system-ui,-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;text-align:center;overflow-x:hidden;overflow-y:auto;";
document.body.appendChild(canvas);

const fullscreenButton = document.createElement("button");
fullscreenButton.type = "button";
fullscreenButton.textContent = "Jouer en plein écran";
fullscreenButton.setAttribute("aria-label", "Jouer en plein écran");
fullscreenButton.style.cssText = "display:block;margin:12px auto;padding:10px 18px;border:1px solid #38bdf8;border-radius:10px;background:linear-gradient(135deg,#0f4c70,#1e293b);color:white;font:600 14px system-ui;cursor:pointer;box-shadow:0 6px 18px #0005;transition:transform .15s,filter .15s;";
fullscreenButton.addEventListener("click", () => {
  if (document.fullscreenElement) {
    document.exitFullscreen();
  } else if (canvas.requestFullscreen) {
    canvas.requestFullscreen();
  }
});
canvas.addEventListener("fullscreenchange", () => {
  const isFullscreen = document.fullscreenElement === canvas;
  canvas.style.width = isFullscreen ? "100vw" : "";
  canvas.style.height = isFullscreen ? "100vh" : "";
  canvas.style.margin = isFullscreen ? "0" : "";
  canvas.style.borderRadius = isFullscreen ? "0" : "";
  canvas.style.transform = isFullscreen ? "none" : "";
  fullscreenButton.textContent = isFullscreen ? "Quitter le plein écran" : "Jouer en plein écran";
});
document.body.appendChild(fullscreenButton);

const ctx = canvas.getContext("2d");
const keys = {};
const rocks = [];
const parts = [];
const customizations = [
  { name: "Bleu d'origine", color: "#38bdf8", accessory: "none" },
  { name: "Rouge + bande", color: "#ef4444", accessory: "stripe" },
  { name: "Vert + aileron", color: "#22c55e", accessory: "spoiler" },
  { name: "Violet + néon", color: "#a78bfa", accessory: "neon" }
];
const difficulties = {
  facile: { rockSpeed: 0.65, maxSpeed: 8, lives: 5 },
  moyen: { rockSpeed: 1, maxSpeed: 7, lives: 3 },
  difficile: { rockSpeed: 1.55, maxSpeed: 6.5, lives: 2 }
};
const difficultySelect = document.createElement("select");
difficultySelect.setAttribute("aria-label", "Niveau de difficulté");
difficultySelect.style.cssText = "display:inline-block;margin:0 4px;padding:9px 12px;border-radius:9px;background:#1e293b;color:white;border:1px solid #475569;font:inherit;";
for (const [level, label] of [["facile", "Facile"], ["moyen", "Moyen"], ["difficile", "Difficile"]]) {
  const option = document.createElement("option");
  option.value = level;
  option.textContent = label;
  difficultySelect.appendChild(option);
}
difficultySelect.value = "moyen";
document.body.insertBefore(difficultySelect, canvas);
const customizationSelect = document.createElement("select");
customizationSelect.setAttribute("aria-label", "Personnalisation du véhicule");
customizationSelect.style.cssText = "display:inline-block;margin:0 4px;padding:9px 12px;border-radius:9px;background:#1e293b;color:white;border:1px solid #475569;font:inherit;";
customizations.forEach((customization, index) => {
  const option = document.createElement("option");
  option.value = index;
  option.textContent = index === 0 ? customization.name : `${customization.name} · pièce nécessaire`;
  option.disabled = index > 0;
  customizationSelect.appendChild(option);
});
document.body.insertBefore(customizationSelect, canvas);
let difficulty = difficulties[difficultySelect.value];
let score = 0;
let running = true;
let lives = difficulty.lives;
let frame = 0;
let collectedParts = 0;
let selectedCustomization = 0;

const car = {
  x: 450,
  y: 280,
  angle: 0,
  speed: 0,
  radius: 24,
  color: "#38bdf8"
};

for (let i = 0; i < 10; i++) {
  rocks.push({
    x: 80 + Math.random() * 740,
    y: 80 + Math.random() * 400,
    r: 13 + Math.random() * 12,
    vx: (Math.random() - 0.5) * 2 * difficulty.rockSpeed,
    vy: (Math.random() - 0.5) * 2 * difficulty.rockSpeed,
    rotation: Math.random() * Math.PI * 2,
    colliding: false
  });
}

for (let i = 0; i < 5; i++) {
  parts.push({
    x: 45 + Math.random() * (canvas.width - 90),
    y: 65 + Math.random() * (canvas.height - 130),
    rotation: Math.random() * Math.PI * 2
  });
}

customizationSelect.addEventListener("change", () => {
  selectedCustomization = Number(customizationSelect.value);
  car.color = customizations[selectedCustomization].color;
});

difficultySelect.addEventListener("change", () => {
  difficulty = difficulties[difficultySelect.value];
  reset();
});

addEventListener("keydown", e => {
  const key = e.key.toLowerCase();
  if (["arrowleft", "arrowright", "arrowup", "arrowdown", " "].includes(key)) e.preventDefault();
  keys[key] = true;
  if ((key === " " || key === "r") && !running) reset();
});
addEventListener("keyup", e => keys[e.key.toLowerCase()] = false);

function pointerPosition(e) {
  const rect = canvas.getBoundingClientRect();
  return {
    x: (e.clientX - rect.left) * canvas.width / rect.width,
    y: (e.clientY - rect.top) * canvas.height / rect.height
  };
}

canvas.addEventListener("pointerdown", e => {
  canvas.setPointerCapture(e.pointerId);
  const point = pointerPosition(e);
  steer(point.x, point.y);
});
canvas.addEventListener("pointermove", e => {
  if (e.buttons || e.pointerType === "touch") {
    const point = pointerPosition(e);
    steer(point.x, point.y);
  }
});

function steer(tx, ty) {
  car.angle = Math.atan2(ty - car.y, tx - car.x);
  car.speed = 3.8;
}

function reset() {
  car.x = 450;
  car.y = 280;
  car.angle = 0;
  car.speed = 0;
  score = 0;
  lives = difficulty.lives;
  frame = 0;
  running = true;
  for (const rock of rocks) {
    rock.x = rock.r + Math.random() * (canvas.width - rock.r * 2);
    rock.y = rock.r + Math.random() * (canvas.height - rock.r * 2);
    rock.vx = (Math.random() - 0.5) * 2 * difficulty.rockSpeed;
    rock.vy = (Math.random() - 0.5) * 2 * difficulty.rockSpeed;
    rock.rotation = Math.random() * Math.PI * 2;
    rock.colliding = false;
  }
}

function update() {
  if (!running) return;
  frame++;
  if (frame % 60 === 0) score++;

  if (keys.arrowleft || keys.a) car.angle -= 0.055;
  if (keys.arrowright || keys.d) car.angle += 0.055;
  if (keys.arrowup || keys.w) car.speed += 0.18;
  if (keys.arrowdown || keys.s) car.speed -= 0.12;

  car.speed *= 0.985;
  car.speed = Math.max(-4, Math.min(difficulty.maxSpeed, car.speed));
  car.x += Math.cos(car.angle) * car.speed;
  car.y += Math.sin(car.angle) * car.speed;

  if (car.x - car.radius < 0 || car.x + car.radius > canvas.width) {
    car.x = Math.max(car.radius, Math.min(canvas.width - car.radius, car.x));
    car.speed *= -0.35;
  }
  if (car.y - car.radius < 0 || car.y + car.radius > canvas.height) {
    car.y = Math.max(car.radius, Math.min(canvas.height - car.radius, car.y));
    car.speed *= -0.35;
  }

  for (const rock of rocks) {
    rock.x += rock.vx;
    rock.y += rock.vy;
    rock.rotation += Math.hypot(rock.vx, rock.vy) / rock.r;
    if (rock.x < rock.r || rock.x > canvas.width - rock.r) rock.vx *= -1;
    if (rock.y < rock.r || rock.y > canvas.height - rock.r) rock.vy *= -1;

    const dx = rock.x - car.x;
    const dy = rock.y - car.y;
    const dist = Math.hypot(dx, dy);
    const minDist = rock.r + car.radius;

    if (dist < minDist) {
      const nx = dx / (dist || 1);
      const ny = dy / (dist || 1);
      rock.x += nx * (minDist - dist);
      rock.y += ny * (minDist - dist);
      rock.vx += nx * Math.abs(car.speed) * 0.55;
      rock.vy += ny * Math.abs(car.speed) * 0.55;
      car.speed *= 0.75;
      if (!rock.colliding) {
        rock.colliding = true;
        lives--;
        if (lives <= 0) running = false;
      }
    } else if (dist > minDist + 4) {
      rock.colliding = false;
    }
  }

  for (const part of parts) {
    part.rotation += 0.035;
    if (Math.hypot(part.x - car.x, part.y - car.y) < car.radius + 13) {
      collectedParts++;
      score += 5;
      const unlockIndex = Math.min(collectedParts, customizations.length - 1);
      if (unlockIndex > 0) {
        const option = customizationSelect.options[unlockIndex];
        option.disabled = false;
        option.textContent = customizations[unlockIndex].name;
      }
      part.x = 45 + Math.random() * (canvas.width - 90);
      part.y = 65 + Math.random() * (canvas.height - 130);
    }
  }
}

function draw() {
  const gradient = ctx.createLinearGradient(0, 0, 0, canvas.height);
  gradient.addColorStop(0, "#234332");
  gradient.addColorStop(1, "#0f2419");
  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, canvas.width, canvas.height);

  // Grille perspective : les lignes se resserrent vers le haut.
  ctx.save();
  ctx.lineWidth = 1.5;
  ctx.strokeStyle = "rgba(170,205,150,.22)";
  for (let i = 0; i <= 22; i++) {
    const x = i * canvas.width / 22;
    ctx.beginPath();
    ctx.moveTo(canvas.width / 2 + (x - canvas.width / 2) * 0.28, 0);
    ctx.lineTo(x, canvas.height);
    ctx.stroke();
  }
  for (let y = 20; y < canvas.height; y += 40) {
    ctx.globalAlpha = 0.35 + y / canvas.height * 0.65;
    ctx.beginPath();
    ctx.moveTo(0, y);
    ctx.lineTo(canvas.width, y);
    ctx.stroke();
  }
  ctx.restore();

  // Ombres des rochers.
  for (const rock of rocks) {
    ctx.fillStyle = "rgba(0,0,0,.28)";
    ctx.beginPath();
    ctx.ellipse(rock.x + 5, rock.y + 7, rock.r * 1.05, rock.r * 0.55, 0, 0, Math.PI * 2);
    ctx.fill();
  }

  // Boules à pics métalliques qui roulent, triées par profondeur.
  [...rocks].sort((a, b) => a.y - b.y).forEach(rock => {
    ctx.save();
    ctx.translate(rock.x, rock.y);
    ctx.rotate(rock.rotation);

    ctx.fillStyle = "#94a3b8";
    ctx.beginPath();
    for (let i = 0; i < 16; i++) {
      const angle = i / 16 * Math.PI * 2;
      const spike = i % 2 === 0;
      const radius = spike ? rock.r * 1.45 : rock.r * 0.85;
      const px = Math.cos(angle) * radius;
      const py = Math.sin(angle) * radius;
      if (i === 0) ctx.moveTo(px, py);
      else ctx.lineTo(px, py);
    }
    ctx.closePath();
    ctx.fill();

    ctx.fillStyle = "#475569";
    ctx.beginPath();
    ctx.arc(0, 0, rock.r * 0.86, 0, Math.PI * 2);
    ctx.fill();

    ctx.fillStyle = "#cbd5e1";
    ctx.beginPath();
    ctx.arc(-rock.r * 0.25, -rock.r * 0.28, rock.r * 0.48, Math.PI * 0.9, Math.PI * 2.05);
    ctx.closePath();
    ctx.fill();

    ctx.fillStyle = "#1e293b";
    ctx.beginPath();
    ctx.arc(rock.r * 0.22, rock.r * 0.18, rock.r * 0.16, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
  });

  // Pièces brillantes à récupérer pour débloquer des styles de voiture.
  for (const part of parts) {
    ctx.save();
    ctx.translate(part.x, part.y);
    ctx.rotate(part.rotation);
    ctx.fillStyle = "#facc15";
    ctx.strokeStyle = "#fff7ae";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.roundRect(-8, -8, 16, 16, 4);
    ctx.fill();
    ctx.stroke();
    ctx.fillStyle = "#713f12";
    ctx.font = "bold 11px system-ui";
    ctx.textAlign = "center";
    ctx.textBaseline = "middle";
    ctx.fillText("+", 0, 0);
    ctx.restore();
  }

  // Voiture avec ombre, carrosserie surélevée et reflets.
  ctx.save();
  ctx.translate(car.x + 7, car.y + 10);
  ctx.rotate(car.angle);
  ctx.fillStyle = "rgba(0,0,0,.38)";
  ctx.beginPath();
  ctx.ellipse(0, 4, 29, 19, 0, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();

  ctx.save();
  ctx.translate(car.x, car.y - 5);
  ctx.rotate(car.angle);

  ctx.fillStyle = "#075985";
  ctx.beginPath();
  ctx.roundRect(-24, -13, 48, 31, 8);
  ctx.fill();

  ctx.fillStyle = car.color;
  ctx.beginPath();
  ctx.roundRect(-24, -16, 48, 32, 8);
  ctx.fill();

  const bodyLight = ctx.createLinearGradient(-24, 0, 24, 0);
  bodyLight.addColorStop(0, "rgba(255,255,255,.05)");
  bodyLight.addColorStop(0.5, "rgba(255,255,255,.45)");
  bodyLight.addColorStop(1, "rgba(255,255,255,.05)");
  ctx.fillStyle = bodyLight;
  ctx.fillRect(-23, -14, 46, 7);

  ctx.fillStyle = "#0f172a";
  ctx.fillRect(-9, -11, 22, 22);
  ctx.fillStyle = "#bae6fd";
  ctx.fillRect(-5, -9, 14, 18);

  const accessory = customizations[selectedCustomization].accessory;
  if (accessory === "stripe") {
    ctx.fillStyle = "#fff7ed";
    ctx.fillRect(-22, -3, 44, 5);
  } else if (accessory === "spoiler") {
    ctx.fillStyle = "#14532d";
    ctx.fillRect(-26, -17, 5, 25);
    ctx.fillRect(-30, -19, 10, 4);
    ctx.fillRect(-30, 8, 10, 4);
  } else if (accessory === "neon") {
    ctx.strokeStyle = "#e9d5ff";
    ctx.lineWidth = 2;
    ctx.shadowColor = "#c084fc";
    ctx.shadowBlur = 12;
    ctx.strokeRect(-22, -14, 44, 28);
    ctx.shadowBlur = 0;
  }

  ctx.fillStyle = "#111827";
  ctx.fillRect(-19, -21, 13, 6);
  ctx.fillRect(7, -21, 13, 6);
  ctx.fillRect(-19, 15, 13, 6);
  ctx.fillRect(7, 15, 13, 6);

  ctx.fillStyle = "#fef08a";
  ctx.fillRect(20, -10, 4, 7);
  ctx.fillRect(20, 3, 4, 7);
  ctx.restore();

  ctx.fillStyle = "white";
  ctx.font = "700 20px system-ui";
  ctx.fillText("Score : " + score, 20, 32);
  ctx.font = "14px system-ui";
  ctx.fillText("Vies : " + "♥ ".repeat(lives), 20, 54);
  ctx.fillText("Pièces : " + collectedParts + " · Ramasse-les pour débloquer des styles !", 20, 76);
  ctx.fillText("Flèches ou WASD · souris / tactile · R pour recommencer", 20, canvas.height - 18);

  if (!running) {
    ctx.fillStyle = "rgba(15, 23, 42, .8)";
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.textAlign = "center";
    ctx.fillStyle = "white";
    ctx.font = "700 42px system-ui";
    ctx.fillText("Partie terminée", canvas.width / 2, canvas.height / 2 - 18);
    ctx.font = "20px system-ui";
    ctx.fillText("Score : " + score + " · Espace ou R pour rejouer", canvas.width / 2, canvas.height / 2 + 24);
    ctx.textAlign = "start";
  }
}

function loop() {
  update();
  draw();
  requestAnimationFrame(loop);
}

loop();