/* FRONTLINE: DUSTFALL — standalone browser FPS. Requires WebGL and a network connection for Three.js. */
(() => {
	const boot = () => {
		if (!window.THREE) { setTimeout(boot, 40); return; }
		const THREE = window.THREE;
		document.body.innerHTML = '';
		Object.assign(document.body.style, { margin: '0', overflow: 'hidden', background: '#10151a', color: '#eaf2f4', font: '14px system-ui, sans-serif' });
		const style = document.createElement('style');
		style.textContent = `*{box-sizing:border-box}#game{position:fixed;inset:0}canvas{display:block}#hud{position:fixed;inset:0;pointer-events:none;display:none;text-shadow:0 2px 4px #000}#top{position:absolute;top:20px;left:22px;display:flex;gap:12px;align-items:center}.pill{padding:9px 13px;background:#101820c9;border:1px solid #ffffff25;border-radius:4px;letter-spacing:.08em}.bar{width:150px;height:7px;background:#303a3e;margin-top:5px}.fill{height:100%;background:#c9e36a;transition:width .15s}.red{background:#ee675b}#ammo{position:absolute;right:26px;bottom:22px;text-align:right;font-size:26px;font-weight:700}#ammo small{font-size:12px;color:#b9c3c4;display:block;letter-spacing:.12em}#cross{position:absolute;left:50%;top:50%;width:18px;height:18px;transform:translate(-50%,-50%)}#cross:before,#cross:after{content:'';position:absolute;background:#eaf2f4;box-shadow:0 0 3px #111}#cross:before{width:2px;height:18px;left:8px}#cross:after{height:2px;width:18px;top:8px}#hint{position:absolute;bottom:24px;left:50%;transform:translateX(-50%);color:#e2e8df;letter-spacing:.12em}#overlay{position:fixed;inset:0;background:linear-gradient(90deg,#091117e8,#091117a8),radial-gradient(ellipse at 70% 40%,#52605255,transparent 65%);display:flex;align-items:center;justify-content:center;z-index:5}#panel{width:min(500px,92vw);padding:36px;background:#111a20ed;border:1px solid #d5e0d233;box-shadow:0 22px 90px #0009}h1{font-size:40px;line-height:1;margin:0 0 8px;letter-spacing:.09em}h1 span{color:#c9e36a}#sub{color:#aab8ba;margin-bottom:26px}button,select{width:100%;padding:12px 14px;margin:5px 0;background:#202d32;color:#eff4ed;border:1px solid #435157;text-align:left;font:inherit;cursor:pointer}button:hover{background:#34464a;border-color:#c9e36a}button.primary{background:#c9e36a;color:#101613;font-weight:800;text-align:center;border:0;margin-top:14px}#note{font-size:12px;color:#9daaad;line-height:1.6;margin-top:17px}#banner{position:absolute;top:34%;width:100%;text-align:center;font-size:34px;font-weight:800;letter-spacing:.14em;display:none}#banner small{display:block;font-size:14px;font-weight:400;letter-spacing:.04em;margin-top:12px}#damage{position:fixed;inset:0;pointer-events:none;box-shadow:inset 0 0 100px #e3352540;opacity:0;transition:opacity .2s}`;
		style.textContent += `#panel{animation:panelIn .35s ease-out}@keyframes panelIn{from{opacity:0;transform:translateY(12px)}to{opacity:1;transform:none}}.pill{backdrop-filter:blur(5px)}.fill{transition:width .25s ease}button{transition:background .16s,border-color .16s,transform .16s}button:hover{transform:translateX(2px)}#cross{transition:transform .1s,opacity .1s}#cross.hit{transform:translate(-50%,-50%) scale(1.35) rotate(45deg)}#cross.hit:before,#cross.hit:after{background:#ee675b}`;
		document.head.appendChild(style);
		const root = document.createElement('div'); root.id = 'game'; document.body.appendChild(root);
		const hud = document.createElement('div'); hud.id = 'hud'; hud.innerHTML = '<div id="top"><div class="pill">VITALITÉ <div class="bar"><div id="life" class="fill"></div></div></div><div class="pill" id="kills">ÉLIMINATIONS&nbsp; 0</div><div class="pill" id="modeLabel">SURVIE</div></div><div id="cross"></div><div id="hint">ZQSD DÉPLACER&nbsp; · &nbsp;CLIC TIRER&nbsp; · &nbsp;R RECHARGER&nbsp; · &nbsp;ÉCHAP PAUSE</div><div id="ammo"><small>ARME</small><span id="weapon">PISTOLET</span><br><span id="mag">12</span> <small style="display:inline">/</small> <span id="reserve" style="font-size:17px">60</span></div><div id="banner"></div></div><div id="damage"></div>'; document.body.appendChild(hud);
		const overlay = document.createElement('div'); overlay.id = 'overlay'; document.body.appendChild(overlay);
		const modes = ['Survie', 'Deathmatch', 'Entraînement', 'Capture de zone'];
		const guns = [
			{ name: 'Pistolet', label: 'PISTOLET', damage: 34, mag: 12, reserve: 60, rate: 280, spread: .012, reload: 1.25, auto: false },
			{ name: 'Fusil d’assaut', label: 'FUSIL D’ASSAUT', damage: 24, mag: 30, reserve: 150, rate: 105, spread: .027, reload: 1.65, auto: true },
			{ name: 'Sniper', label: 'SNIPER', damage: 100, mag: 5, reserve: 30, rate: 850, spread: .002, reload: 2.1, auto: false },
			{ name: 'Fusil à pompe', label: 'FUSIL À POMPE', damage: 15, mag: 8, reserve: 40, rate: 650, spread: .09, reload: 1.8, auto: false, pellets: 8 },
			{ name: 'Mitraillette', label: 'MITRAILLETTE', damage: 18, mag: 32, reserve: 160, rate: 75, spread: .045, reload: 1.5, auto: true }
		];
		let mode = 'Survie', selectedGun = 0, running = false, started = false, paused = true, health = 100, kills = 0, capture = 0, wave = 1;
		function showMenu(title = 'DUSTFALL', message = 'OPÉRATION FRONTIÈRE · SECTEUR 09') {
			paused = true;
			overlay.style.display = 'flex'; hud.style.display = started ? 'block' : 'none';
			overlay.innerHTML = `<section id="panel"><h1><span>◆</span> ${title}</h1><div id="sub">${message}</div><label>MODE DE JEU</label><select id="modeSelect">${modes.map(m => `<option ${m === mode ? 'selected' : ''}>${m}</option>`).join('')}</select><label>ARME DE DÉPART</label><select id="gunSelect">${guns.map((g, i) => `<option value="${i}" ${i === selectedGun ? 'selected' : ''}>${g.name}</option>`).join('')}</select><button class="primary" id="play">${started ? 'REPRENDRE' : 'DÉPLOYER'}</button><button id="settings">PARAMÈTRES · SENSIBILITÉ</button><button id="quit">QUITTER LA PARTIE</button><div id="note">ZQSD : déplacement · Souris : viser · Clic gauche : tirer · Clic droit : précision<br>R : recharger · Espace : sauter · Maj : courir · Ctrl : s’accroupir · 1–5 : changer d’arme</div></section>`;
			document.getElementById('modeSelect').onchange = e => mode = e.target.value;
			document.getElementById('gunSelect').onchange = e => selectedGun = +e.target.value;
			document.getElementById('play').onclick = () => startGame();
			document.getElementById('settings').onclick = () => { const v = prompt('Sensibilité souris (0.3 à 3)', sensitivity); if (v !== null && Number.isFinite(+v)) sensitivity = Math.max(.3, Math.min(3, +v)); };
			document.getElementById('quit').onclick = () => { if (started) showMenu('DUSTFALL', 'Partie terminée. Choisissez DÉPLOYER pour recommencer.'); };
		}
		let sensitivity = 1;
		showMenu();
		const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' }); renderer.setPixelRatio(Math.min(devicePixelRatio, 2)); renderer.setSize(innerWidth, innerHeight); renderer.shadowMap.enabled = true; renderer.shadowMap.type = THREE.PCFSoftShadowMap; renderer.outputColorSpace = THREE.SRGBColorSpace; renderer.toneMapping = THREE.ACESFilmicToneMapping; renderer.toneMappingExposure = 1.12; renderer.domElement.style.touchAction = 'none'; root.appendChild(renderer.domElement);
		const scene = new THREE.Scene(); scene.background = new THREE.Color(0x8e9b9d); scene.fog = new THREE.FogExp2(0x8e9b9d, .0052);
		const camera = new THREE.PerspectiveCamera(76, innerWidth / innerHeight, .08, 220); camera.rotation.order = 'YXZ';
		const player = new THREE.Object3D(); player.position.set(0, 1.7, 16); scene.add(player); player.add(camera);
		const hemi = new THREE.HemisphereLight(0xc8d7dc, 0x35312b, 2.0); scene.add(hemi);
		const sun = new THREE.DirectionalLight(0xffe3be, 3.2); sun.position.set(-25, 40, 20); sun.castShadow = true; sun.shadow.mapSize.set(2048, 2048); sun.shadow.camera.left = -55; sun.shadow.camera.right = 55; sun.shadow.camera.top = 55; sun.shadow.camera.bottom = -55; sun.shadow.bias = -.0003; sun.shadow.normalBias = .025; scene.add(sun);
		const fillLight = new THREE.DirectionalLight(0x8db7c5, .65); fillLight.position.set(28, 12, -18); scene.add(fillLight);
		const mat = (color, rough = .9) => new THREE.MeshStandardMaterial({ color, roughness: rough });
		const photoLoader = new THREE.TextureLoader();
		const photoTexture = (url, repeatX = 24, repeatY = 24) => {
			const texture = photoLoader.load(url);
			texture.wrapS = texture.wrapT = THREE.RepeatWrapping;
			texture.repeat.set(repeatX, repeatY);
			texture.colorSpace = THREE.SRGBColorSpace;
			texture.anisotropy = Math.min(8, renderer.capabilities.getMaxAnisotropy());
			return texture;
		};
		const groundPhoto = photoTexture('https://images.unsplash.com/photo-1500534314209-a25ddb2bd429?auto=format&fit=crop&w=1024&q=85');
		const asphaltPhoto = photoTexture('https://images.unsplash.com/photo-1590765914215-8b0e1a9e9c1c?auto=format&fit=crop&w=1024&q=85', 5, 30);
		const groundMat = new THREE.MeshStandardMaterial({ map: groundPhoto, color: 0xb1a98c, roughness: .96 });
		const concrete = mat(0x77766b), wallmat = mat(0x575e5d), crateMat = mat(0x806848);
		const asphalt = new THREE.MeshStandardMaterial({ map: asphaltPhoto, color: 0x77776f, roughness: .88 });
		const trim = mat(0x3a4445), glass = new THREE.MeshStandardMaterial({ color: 0x596f70, roughness: .22, metalness: .35 });
		function box(x, y, z, sx, sy, sz, material, collide = true) { const m = new THREE.Mesh(new THREE.BoxGeometry(sx, sy, sz), material); m.position.set(x, y, z); m.castShadow = true; m.receiveShadow = true; scene.add(m); if (collide) obstacles.push({ x, z, hx: sx / 2, hz: sz / 2, top: y + sy / 2 }); return m; }
		const obstacles = [];
		box(0, -.35, 0, 180, .7, 180, groundMat, false);
		box(0, .01, 0, 10, .08, 118, asphalt, false);
		box(0, .025, 0, .18, .025, 118, mat(0xaaa58b), false);
		for (let i = -5; i <= 5; i++) if (i !== 0) box(0, .065, i * 9, .18, .025, 3.2, mat(0xb9ad83), false);
		for (let i = -65; i < 66; i += 8) {
			const patch = new THREE.Mesh(new THREE.CircleGeometry(.18 + Math.random() * .28, 7), mat(0x252a27, .35)); patch.rotation.x = -Math.PI / 2; patch.position.set((Math.random() - .5) * 9, .042, i + Math.random() * 3); scene.add(patch);
		}
		const zone = new THREE.Group(); const zoneRing = new THREE.Mesh(new THREE.RingGeometry(7, 7.28, 48), new THREE.MeshBasicMaterial({ color: 0xc9e36a, transparent: true, opacity: .38, side: THREE.DoubleSide, depthWrite: false })); zoneRing.rotation.x = -Math.PI / 2; zoneRing.position.y = .09; zone.add(zoneRing); zone.position.set(0, 0, -4); scene.add(zone);
		// Original compact combat district: low industrial blocks, cover, alleys and raised firing positions.
		for (const [x, z, w, d, h] of [[-21, -18, 18, 14, 9], [22, -21, 17, 15, 12], [-25, 16, 16, 18, 8], [24, 18, 19, 15, 10], [-8, -39, 19, 10, 7], [13, 40, 23, 11, 8]]) {
			box(x, h / 2, z, w, h, d, wallmat); box(x, h + .12, z, w + .15, .25, d + .15, trim);
			for (let xx = -1; xx <= 1; xx++) for (let yy = 0; yy < 2; yy++) { const win = box(x + xx * w * .27, 2.3 + yy * 3, z - d / 2 - .03, w * .14, 1.0, .07, glass, false); win.castShadow = false; }
			// Rooftop access blocks suggest tactical high ground.
			if (h > 8) { box(x + w * .28, h + .8, z, 2, 1.6, 2, concrete); }
		}
		for (const [x, z] of [[-10, -9], [11, -8], [-13, 11], [12, 13], [-5, 29], [6, -28], [-32, -2], [34, 1]]) {
			box(x, .8, z, 2.5, 1.6, 2.2, crateMat); box(x, .8, z, 2.58, .08, .08, trim, false);
		}
		// Open side alleys and a traversable underpass.
		box(-8, 1.6, 0, 1, 3.2, 8, concrete); box(8, 1.6, 0, 1, 3.2, 8, concrete);
		for (const [x, z] of [[-37, -30], [-34, -30], [35, 28], [38, 28]]) box(x, 2, z, 4, 4, 4, crateMat);
		const gunModel = new THREE.Group(); camera.add(gunModel);
		const gunBody = new THREE.Mesh(new THREE.BoxGeometry(.2, .2, .65), mat(0x273238, .45)); gunBody.position.set(.32, -.27, -.55); gunModel.add(gunBody);
		const barrel = new THREE.Mesh(new THREE.CylinderGeometry(.035, .045, .36, 10), mat(0x111719, .35)); barrel.rotation.x = Math.PI / 2; barrel.position.set(.32, -.22, -.99); gunModel.add(barrel);
		const sight = new THREE.Mesh(new THREE.BoxGeometry(.09, .08, .11), mat(0x64745b, .4)); sight.position.set(.32, -.14, -.65); gunModel.add(sight);
		const muzzleFlash = new THREE.Mesh(new THREE.PlaneGeometry(.3, .3), new THREE.MeshBasicMaterial({ color: 0xffc15c, transparent: true, opacity: .9, side: THREE.DoubleSide, depthWrite: false })); muzzleFlash.position.set(.32, -.22, -1.12); muzzleFlash.visible = false; gunModel.add(muzzleFlash); const muzzleLight = new THREE.PointLight(0xffa64a, 0, 3); muzzleLight.position.copy(muzzleFlash.position); gunModel.add(muzzleLight);
		const handMat = mat(0x59615a, .75), gloveMat = mat(0x252b29, .9);
		const rightHand = new THREE.Mesh(new THREE.CapsuleGeometry(.08, .18, 4, 8), gloveMat); rightHand.position.set(.38, -.43, -.42); rightHand.rotation.x = -.75; gunModel.add(rightHand);
		const rightArm = new THREE.Mesh(new THREE.CapsuleGeometry(.11, .34, 4, 8), handMat); rightArm.position.set(.48, -.53, -.12); rightArm.rotation.x = -1.15; gunModel.add(rightArm);
		const raycaster = new THREE.Raycaster(), keys = {}, enemies = [], enemyMeshes = [], tracers = [];
		let ammo = [], reloading = false, reloadEnd = 0, lastShot = 0, velY = 0, onGround = true, firing = false, aiming = false, crouch = false, pointerLocked = false, lastTime = performance.now(), soundCtx, recoil = 0, shotFlash = 0, movePhase = 0, footstepAt = 0;
		function sound(freq = 100, duration = .08, type = 'sawtooth', gain = .035) { try { soundCtx ||= new AudioContext(); const o = soundCtx.createOscillator(), g = soundCtx.createGain(); o.type = type; o.frequency.value = freq; g.gain.setValueAtTime(gain, soundCtx.currentTime); g.gain.exponentialRampToValueAtTime(.001, soundCtx.currentTime + duration); o.connect(g); g.connect(soundCtx.destination); o.start(); o.stop(soundCtx.currentTime + duration); } catch { } }
		function updateGunHud() { const g = guns[selectedGun]; document.getElementById('weapon').textContent = g.label; document.getElementById('mag').textContent = ammo[selectedGun]?.mag ?? g.mag; document.getElementById('reserve').textContent = ammo[selectedGun]?.reserve ?? g.reserve; }
		function resetAmmo() { ammo = guns.map(g => ({ mag: g.mag, reserve: g.reserve })); updateGunHud(); }
		function spawnEnemy() {
			if (mode === 'Entraînement') {
				const stand = new THREE.Group();
				const post = new THREE.Mesh(new THREE.BoxGeometry(.12, 1.25, .12), mat(0x4a5050)); post.position.y = .62;
				const base = new THREE.Mesh(new THREE.CylinderGeometry(.48, .55, .12, 12), mat(0x303736)); base.position.y = .06;
				const torso = new THREE.Mesh(new THREE.BoxGeometry(.62, 1.15, .38), mat(0xd0a74f)); torso.position.y = 1.22;
				const target = new THREE.Mesh(new THREE.CylinderGeometry(.24, .24, .025, 20), mat(0xe3e1ce)); target.rotation.x = Math.PI / 2; target.position.set(0, 1.25, -.21);
				const bullseye = new THREE.Mesh(new THREE.CylinderGeometry(.08, .08, .028, 16), mat(0xc85b4d)); bullseye.rotation.x = Math.PI / 2; bullseye.position.set(0, 1.25, -.23);
				stand.add(post, base, torso, target, bullseye); stand.position.set((Math.random() - .5) * 36, 0, -12 - Math.random() * 27);
				stand.traverse(o => { if (o.isMesh) { o.castShadow = true; o.userData.enemy = true; } }); scene.add(stand);
				enemies.push({ mesh: stand, hp: 1, target: true, next: 0, variant: 'target', baseY: 0 }); enemyMeshes.push(torso, target, bullseye); return;
			}
			const variant = Math.random();
			const rifleman = variant < .45, heavy = variant > .78;
			const uniform = heavy ? 0x303f3a : rifleman ? 0x53655a : 0x4d5550;
			const armor = heavy ? 0x202826 : 0x343f3d;
			const group = new THREE.Group();
			const leftLeg = new THREE.Mesh(new THREE.BoxGeometry(.25, .68, .32), mat(0x343e38)); leftLeg.position.set(-.19, .36, 0);
			const rightLeg = new THREE.Mesh(new THREE.BoxGeometry(.25, .68, .32), mat(0x343e38)); rightLeg.position.set(.19, .36, 0);
			const pelvis = new THREE.Mesh(new THREE.BoxGeometry(.68, .22, .42), mat(armor)); pelvis.position.y = .78;
			const body = new THREE.Mesh(new THREE.BoxGeometry(.72, .82, .44), mat(uniform)); body.position.y = 1.22;
			const vest = new THREE.Mesh(new THREE.BoxGeometry(.76, .55, .48), mat(armor)); vest.position.set(0, 1.25, -.03);
			const head = new THREE.Mesh(new THREE.SphereGeometry(.23, 12, 9), mat(heavy ? 0x9a8068 : 0xb48c6a)); head.position.y = 1.82;
			const helmet = new THREE.Mesh(new THREE.SphereGeometry(.255, 12, 6, 0, Math.PI * 2, 0, Math.PI * .55), mat(heavy ? 0x252e2c : 0x3e4946)); helmet.position.set(0, 1.88, 0);
			const armGeo = new THREE.CapsuleGeometry(.09, .48, 4, 8);
			const leftArm = new THREE.Mesh(armGeo, mat(uniform)); leftArm.position.set(-.48, 1.18, -.08); leftArm.rotation.z = -.18;
			const rightArm = new THREE.Mesh(armGeo, mat(uniform)); rightArm.position.set(.48, 1.18, -.08); rightArm.rotation.z = .18;
			const weapon = new THREE.Mesh(new THREE.BoxGeometry(.09, .11, heavy ? 1.05 : .82), mat(0x171d1d, .4)); weapon.position.set(.34, 1.18, -.55); weapon.rotation.x = -.08;
			const magazine = new THREE.Mesh(new THREE.BoxGeometry(.13, .28, .18), mat(0x252b2b)); magazine.position.set(.34, .98, -.42);
			const enemyFlash = new THREE.Mesh(new THREE.PlaneGeometry(.22, .22), new THREE.MeshBasicMaterial({ color: 0xffb45c, transparent: true, opacity: .95, side: THREE.DoubleSide, depthWrite: false })); enemyFlash.position.set(.34, 1.18, heavy ? -1.12 : -.98); enemyFlash.visible = false;
			const enemyLight = new THREE.PointLight(0xff9a3c, 0, 3.5); enemyLight.position.copy(enemyFlash.position);
			group.add(leftLeg, rightLeg, pelvis, body, vest, head, helmet, leftArm, rightArm, weapon, magazine, enemyFlash, enemyLight);
			group.position.set((Math.random() - .5) * 52, .05, -25 - Math.random() * 25); group.rotation.y = Math.random() * Math.PI * 2;
			group.traverse(o => { if (o.isMesh) { o.castShadow = true; o.receiveShadow = true; o.userData.enemy = true; } }); scene.add(group);
			const hp = heavy ? 125 : rifleman ? 85 : 70;
			enemies.push({ mesh: group, hp, maxHp: hp, target: false, next: performance.now() + 800 + Math.random() * 1800, cover: heavy ? true : Math.random() > .5, variant: heavy ? 'heavy' : rifleman ? 'rifleman' : 'scout', speed: heavy ? .9 : rifleman ? 1.25 : 1.65, phase: Math.random() * 6.28, baseY: .05, leftArm, rightArm, leftLeg, rightLeg, weapon, enemyFlash, enemyLight, weaponKick: 0, shotFlash: 0 });
			enemyMeshes.push(body, vest, head, helmet, leftLeg, rightLeg, leftArm, rightArm);
		}
		function fillEnemies() { for (const e of enemies) scene.remove(e.mesh); enemies.length = 0; enemyMeshes.length = 0; const n = mode === 'Entraînement' ? 9 : mode === 'Deathmatch' ? 12 : 6 + wave * 2; for (let i = 0; i < n; i++)spawnEnemy(); }
		function startGame() {
			mode = document.getElementById('modeSelect')?.value || mode; selectedGun = +(document.getElementById('gunSelect')?.value ?? selectedGun); overlay.style.display = 'none'; hud.style.display = 'block'; paused = false; started = true; running = true; health = 100; kills = 0; capture = 0; wave = 1; player.position.set(0, 1.7, 16); velY = 0; resetAmmo(); fillEnemies(); updateHud(); renderer.domElement.requestPointerLock?.();
		}
		function updateHud() { document.getElementById('life').style.width = health + '%'; document.getElementById('life').classList.toggle('red', health < 35); document.getElementById('kills').innerHTML = 'ÉLIMINATIONS&nbsp; ' + kills; document.getElementById('modeLabel').textContent = mode.toUpperCase(); updateGunHud(); }
		function reload() { const a = ammo[selectedGun], g = guns[selectedGun]; if (reloading || a.mag === g.mag || a.reserve <= 0) return; reloading = true; reloadEnd = performance.now() + g.reload * 1000; sound(220, .15, 'triangle'); }
		function shoot() {
			const now = performance.now(), g = guns[selectedGun], a = ammo[selectedGun]; if (paused || reloading || now - lastShot < g.rate) return; if (a.mag <= 0) { sound(180, .05, 'square', .012); reload(); return; } lastShot = now; a.mag--; updateGunHud(); sound(selectedGun === 2 ? 65 : selectedGun === 3 ? 80 : 110, .085, 'sawtooth', .045); recoil = Math.min(.18, recoil + (selectedGun === 2 ? .24 : selectedGun === 3 ? .20 : .12)); shotFlash = .07; muzzleFlash.visible = true; muzzleFlash.rotation.z = Math.random() * Math.PI; muzzleLight.intensity = 2.2;
			gunModel.position.z = .09; setTimeout(() => gunModel.position.z = 0, 55);
			const origin = camera.getWorldPosition(new THREE.Vector3()), dir = new THREE.Vector3(); camera.getWorldDirection(dir); let hitAnything = false;
			camera.rotation.x -= recoil * .018;
			const cross = document.getElementById('cross');
			for (let i = 0; i < (g.pellets || 1); i++) {
				const d = dir.clone().add(new THREE.Vector3((Math.random() - .5) * g.spread, (Math.random() - .5) * g.spread, (Math.random() - .5) * g.spread)).normalize(); raycaster.set(origin, d); raycaster.far = selectedGun === 2 ? 160 : 85; const hit = raycaster.intersectObjects(enemyMeshes, false)[0];
				if (hit) { const e = enemies.find(en => en.mesh === hit.object || en.mesh === hit.object.parent || en.mesh === hit.object.parent?.parent); if (e && !e.dead) { const headshot = hit.object.geometry?.type === 'SphereGeometry'; const damage = headshot ? Math.max(g.damage * 1.75, 100) : g.damage; e.hp -= damage; e.hitUntil = now + 120; if (e.target) e.hp = 0; hitAnything = true; cross?.classList.add('hit'); setTimeout(() => cross?.classList.remove('hit'), 85); if (headshot) sound(620, .08, 'sine', .018); if (e.hp <= 0) { e.dead = true; e.deathAt = now; kills++; document.getElementById('kills').innerHTML = 'ÉLIMINATIONS&nbsp; ' + kills; } } }
				const end = origin.clone().addScaledVector(d, hit?.distance || raycaster.far); const geom = new THREE.BufferGeometry().setFromPoints([origin.clone().addScaledVector(d, .25), end]); const tracer = new THREE.Line(geom, new THREE.LineBasicMaterial({ color: selectedGun === 2 ? 0xe7f4cc : 0xffd38a, transparent: true, opacity: .48, depthWrite: false })); scene.add(tracer); tracers.push({ line: tracer, end: now + 55 });
			}
			if (hitAnything) sound(420, .045, 'triangle', .015);
			if (mode === 'Capture de zone' && hitAnything) capture = Math.min(100, capture + 5);
		}
		function damagePlayer(amount) { health = Math.max(0, health - amount); updateHud(); const d = document.getElementById('damage'); d.style.opacity = '.9'; setTimeout(() => d.style.opacity = '0', 140); if (health <= 0) { running = false; document.exitPointerLock?.(); showMenu('MISSION ÉCHOUÉE', `Éliminations : ${kills} · ${mode}`); } }
		function clampPlayer() { const r = crouch ? .43 : .55; player.position.x = THREE.MathUtils.clamp(player.position.x, -77, 77); player.position.z = THREE.MathUtils.clamp(player.position.z, -77, 77); for (const o of obstacles) { if (player.position.y > o.top + .8) continue; const dx = player.position.x - o.x, dz = player.position.z - o.z; if (Math.abs(dx) < o.hx + r && Math.abs(dz) < o.hz + r) { const px = o.hx + r - Math.abs(dx), pz = o.hz + r - Math.abs(dz); if (px < pz) player.position.x += Math.sign(dx || 1) * px; else player.position.z += Math.sign(dz || 1) * pz; } } }
		function updateEnemies(dt, now) {
			for (const e of enemies) {
				if (e.dead) { const t = Math.min(1, (now - e.deathAt) / 450); e.mesh.rotation.z = t * 1.35; e.mesh.position.y -= dt * (e.variant === 'target' ? 0 : 1.8); e.mesh.scale.setScalar(Math.max(.02, 1 - t * .45)); if (t >= 1) scene.remove(e.mesh); continue; }
				if (e.hitUntil > now) e.mesh.position.y += Math.sin(now * .04) * .006;
				const p = e.mesh.position, dist = p.distanceTo(player.position);
				if (!e.target && dist > 10) {
					const dir = player.position.clone().sub(p); dir.y = 0; dir.normalize();
					if (dist > 7) {
						p.addScaledVector(dir, dt * (e.speed || 1.4));
						e.mesh.rotation.y = Math.atan2(dir.x, dir.z);
						const stride = Math.sin(now * .008 + e.phase);
						p.y = e.baseY + Math.abs(Math.cos(now * .008 + e.phase)) * .018;
						if (e.leftLeg) e.leftLeg.rotation.x = stride * .52;
						if (e.rightLeg) e.rightLeg.rotation.x = -stride * .52;
						if (e.leftArm) { e.leftArm.rotation.x = stride * .38; e.leftArm.rotation.z = -.18 - stride * .08; }
						if (e.rightArm) { e.rightArm.rotation.x = -.65 - stride * .12; e.rightArm.rotation.z = .18; }
					} else {
						p.y += (e.baseY - p.y) * Math.min(1, dt * 8);
						if (e.leftLeg) e.leftLeg.rotation.x *= Math.max(0, 1 - dt * 8);
						if (e.rightLeg) e.rightLeg.rotation.x *= Math.max(0, 1 - dt * 8);
					}
				} else if (!e.target) {
					e.mesh.rotation.y = Math.atan2(player.position.x - p.x, player.position.z - p.z);
					if (e.leftLeg) e.leftLeg.rotation.x *= Math.max(0, 1 - dt * 10);
					if (e.rightLeg) e.rightLeg.rotation.x *= Math.max(0, 1 - dt * 10);
					if (e.leftArm) { e.leftArm.rotation.x += (-.72 - e.leftArm.rotation.x) * Math.min(1, dt * 10); }
					if (e.rightArm) { e.rightArm.rotation.x += (-.72 - e.rightArm.rotation.x) * Math.min(1, dt * 10); e.rightArm.rotation.z = .18; }
				}
				if (!e.target && dist < 34 && now > e.next) {
					const accuracy = e.variant === 'heavy' ? .72 : e.variant === 'rifleman' ? .58 : .42;
					e.next = now + (e.variant === 'heavy' ? 1450 : e.variant === 'rifleman' ? 1100 : 850) + Math.random() * 900;
					const hit = Math.random() < accuracy;
					if (hit) { damagePlayer((mode === 'Deathmatch' ? 4 : 6) * (e.variant === 'heavy' ? 1.35 : 1)); sound(e.variant === 'heavy' ? 52 : 72, .07, 'square', .018); }
					if (e.enemyFlash) {
						e.enemyFlash.visible = true;
						e.enemyFlash.lookAt(camera.getWorldPosition(new THREE.Vector3()));
						e.enemyLight.intensity = 4.8;
						e.enemyFlash.rotation.z = Math.random() * Math.PI;
						e.enemyFlash.scale.set(1.75, 1.75, 1.75);
						e.shotFlash = .22;
						e.weaponKick = .34;
					}
					if (e.weapon) e.weapon.rotation.x = -.18;
					if (e.rightArm) { e.rightArm.rotation.x = -1.08; e.rightArm.rotation.z = .18; }
					if (e.leftArm) e.leftArm.rotation.x = -.92;
					const origin = e.enemyFlash?.getWorldPosition(new THREE.Vector3()) || e.mesh.position.clone().add(new THREE.Vector3(0, 1.2, 0));
					const target = player.position.clone(); target.y += hit ? (Math.random() - .5) * .12 : (Math.random() - .5) * 1.8;
					const tracerGeom = new THREE.BufferGeometry().setFromPoints([origin, target]);
					const tracer = new THREE.Line(tracerGeom, new THREE.LineBasicMaterial({ color: hit ? 0xff7045 : 0xffd08a, transparent: true, opacity: 1, linewidth: 3, depthWrite: false })); scene.add(tracer); tracers.push({ line: tracer, end: now + 190 });
				}
				if (e.target && now > e.next) { e.next = now + 950; e.mesh.position.x = THREE.MathUtils.clamp(e.mesh.position.x + (Math.random() - .5) * 3.5, -35, 35); }
				if (e.shotFlash > 0) {
					e.shotFlash -= dt;
					if (e.enemyFlash) {
						e.enemyFlash.visible = e.shotFlash > 0;
						e.enemyFlash.scale.multiplyScalar(Math.max(.88, 1 - dt * 2.4));
						e.enemyFlash.rotation.z += dt * 9;
					}
					if (e.enemyLight) e.enemyLight.intensity = Math.max(0, e.shotFlash * 32);
					e.weaponKick = Math.max(0, e.weaponKick - dt * 1.35);
					if (e.weapon) e.weapon.position.z = (e.variant === 'heavy' ? -1.12 : -.98) + e.weaponKick;
					if (e.rightArm) { e.rightArm.rotation.x = -.82 - Math.sin(e.shotFlash * 28) * .14; e.rightArm.rotation.z = .18; }
					if (e.leftArm) e.leftArm.rotation.x = -.72;
					p.y += Math.sin(e.shotFlash * 60) * .012;
				} else {
					if (e.enemyFlash) e.enemyFlash.scale.set(1, 1, 1);
					if (e.weapon) e.weapon.position.z = (e.variant === 'heavy' ? -1.12 : -.98) * .49;
				}
				if (e.shotFlash <= 0 && e.rightArm) {
					e.rightArm.rotation.x += (-.72 - e.rightArm.rotation.x) * Math.min(1, dt * 6);
				}
			}
			const alive = enemies.filter(e => !e.dead).length;
			if (mode === 'Survie' && alive === 0 && running) { wave++; for (let i = 0; i < 5 + wave * 2; i++)spawnEnemy(); }
			if (mode === 'Deathmatch' && kills >= 20) { running = false; document.exitPointerLock?.(); showMenu('VICTOIRE', 'Objectif atteint · 20 éliminations'); }
			if (mode === 'Entraînement' && kills >= 9) { running = false; document.exitPointerLock?.(); showMenu('ENTRAÎNEMENT TERMINÉ', 'Toutes les cibles ont été neutralisées.'); }
			if (mode === 'Capture de zone') { capture = Math.min(100, capture + dt * (distToZone() < 8 ? 3 : 0)); if (capture >= 100) { running = false; document.exitPointerLock?.(); showMenu('ZONE SÉCURISÉE', 'Vous avez contrôlé le point stratégique.'); } document.getElementById('modeLabel').textContent = `ZONE ${Math.floor(capture)}%`; }
		}
		function distToZone() { return Math.hypot(player.position.x, player.position.z + 4); }
		const rainCount = 350, rainGeom = new THREE.BufferGeometry(), rainPositions = new Float32Array(rainCount * 3); for (let i = 0; i < rainCount; i++) { rainPositions[i * 3] = (Math.random() - .5) * 90; rainPositions[i * 3 + 1] = Math.random() * 30; rainPositions[i * 3 + 2] = (Math.random() - .5) * 90; } rainGeom.setAttribute('position', new THREE.BufferAttribute(rainPositions, 3)); const rain = new THREE.Points(rainGeom, new THREE.PointsMaterial({ color: 0xd9e4e6, size: .065, transparent: true, opacity: .36 })); scene.add(rain);
		function tick(now) {
			requestAnimationFrame(tick); const dt = Math.min(.04, (now - lastTime) / 1000); lastTime = now; if (running && !paused) {
				const forward = new THREE.Vector3(-Math.sin(player.rotation.y), 0, -Math.cos(player.rotation.y)), right = new THREE.Vector3(Math.cos(player.rotation.y), 0, -Math.sin(player.rotation.y)); let move = new THREE.Vector3(); if (keys.KeyW || keys.KeyZ) move.add(forward); if (keys.KeyS) move.sub(forward); if (keys.KeyD) move.add(right); if (keys.KeyA || keys.KeyQ) move.sub(right); if (move.lengthSq()) move.normalize(); const speed = (keys.ShiftLeft || keys.ShiftRight ? 9 : 5.5) * (crouch ? .52 : 1); player.position.addScaledVector(move, speed * dt); velY -= 19 * dt; player.position.y += velY * dt; if (player.position.y <= (crouch ? 1.05 : 1.7)) { player.position.y = crouch ? 1.05 : 1.7; velY = 0; onGround = true; } clampPlayer();
				const moving = move.lengthSq() > 0; movePhase += dt * (moving ? 11 : 2); const targetFov = aiming ? 54 : 76; camera.fov += (targetFov - camera.fov) * Math.min(1, dt * 12); camera.updateProjectionMatrix(); camera.position.y += ((crouch ? -.5 : 0) + (moving ? Math.sin(movePhase) * .018 : 0) - camera.position.y) * Math.min(1, dt * 10); recoil = Math.max(0, recoil - dt * .8); gunModel.position.x += ((aiming ? -.12 : 0) - gunModel.position.x) * Math.min(1, dt * 10); gunModel.position.y += ((reloading ? -0.32 : 0) + (moving ? Math.sin(movePhase) * .012 : 0) - recoil * .25 - gunModel.position.y) * Math.min(1, dt * 12); gunModel.position.z += ((aiming ? .08 : 0) + (reloading ? .28 : 0) + recoil - gunModel.position.z) * Math.min(1, dt * 14); gunModel.rotation.z += (reloading ? .38 : 0) - gunModel.rotation.z * .08; if (moving && onGround && Math.sin(movePhase) > 0.985 && now > footstepAt) { footstepAt = now + (keys.ShiftLeft || keys.ShiftRight ? 310 : 430); sound(48, .035, 'triangle', .012); } if (shotFlash > 0) { shotFlash -= dt; muzzleFlash.visible = shotFlash > 0; muzzleLight.intensity = Math.max(0, shotFlash * 32); }
				if (firing && (guns[selectedGun].auto || now - lastShot > guns[selectedGun].rate)) shoot(); if (reloading && now >= reloadEnd) { const g = guns[selectedGun], a = ammo[selectedGun], n = Math.min(g.mag - a.mag, a.reserve); a.mag += n; a.reserve -= n; reloading = false; updateGunHud(); sound(340, .08, 'triangle'); }
				updateEnemies(dt, now); for (let i = tracers.length - 1; i >= 0; i--) { const t = tracers[i]; t.line.material.opacity *= .72; if (now > t.end) { scene.remove(t.line); tracers.splice(i, 1); } } const arr = rain.geometry.attributes.position.array; for (let i = 1; i < arr.length; i += 3) { arr[i] -= dt * 18; arr[i - 1] += dt * 1.2; if (arr[i] < 0) { arr[i] = 28; arr[i - 1] = (Math.random() - .5) * 90; } if (arr[i - 1] > 45) arr[i - 1] = -45; } rain.geometry.attributes.position.needsUpdate = true;
			} renderer.render(scene, camera);
		}
		requestAnimationFrame(tick);
		renderer.domElement.addEventListener('click', () => { if (started && !paused) renderer.domElement.requestPointerLock?.(); });
		document.addEventListener('pointerlockchange', () => { pointerLocked = document.pointerLockElement === renderer.domElement; if (started && pointerLocked) { paused = false; overlay.style.display = 'none'; } else if (started && running && !paused) { paused = true; showMenu('PAUSE', 'Opération suspendue'); } });
		document.addEventListener('mousemove', e => { if (!pointerLocked || paused) return; player.rotation.y -= e.movementX * .0022 * sensitivity; camera.rotation.x -= e.movementY * .0022 * sensitivity; camera.rotation.x = THREE.MathUtils.clamp(camera.rotation.x, -1.48, 1.48); });
		document.addEventListener('keydown', e => { keys[e.code] = true; if (['Space', 'ArrowUp', 'ArrowDown'].includes(e.code)) e.preventDefault(); if (e.repeat) return; if (e.code === 'Escape' && started && running) { if (!paused) { document.exitPointerLock?.(); } else { paused = false; overlay.style.display = 'none'; renderer.domElement.requestPointerLock?.(); } } if (e.code === 'Space' && onGround && !paused) { velY = 7.1; onGround = false; } if (e.code === 'ControlLeft' || e.code === 'ControlRight') { crouch = true; camera.position.y = -0.5; } if (e.code === 'KeyR' && started) reload(); if (e.code.startsWith('Digit') && +e.code.slice(5) >= 1 && +e.code.slice(5) <= 5) { selectedGun = +e.code.slice(5) - 1; reloading = false; updateGunHud(); } });
		document.addEventListener('keyup', e => { keys[e.code] = false; if (e.code === 'ControlLeft' || e.code === 'ControlRight') { crouch = false; camera.position.y = 0; } });
		document.addEventListener('mousedown', e => { if (e.button === 0) { firing = true; if (!guns[selectedGun].auto) shoot(); } if (e.button === 2) { aiming = true; } }); document.addEventListener('mouseup', e => { if (e.button === 0) firing = false; if (e.button === 2) aiming = false; }); document.addEventListener('contextmenu', e => e.preventDefault());
		addEventListener('resize', () => { camera.aspect = innerWidth / innerHeight; camera.updateProjectionMatrix(); renderer.setSize(innerWidth, innerHeight); });
	};
	if (window.THREE) boot(); else { const s = document.createElement('script'); s.src = 'https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.min.js'; s.onload = boot; s.onerror = () => { document.body.innerHTML = '<p style="color:white;background:#111;padding:30px;font:18px sans-serif">Connexion requise pour charger le moteur 3D Three.js.</p>'; }; document.head.appendChild(s); }
})();
